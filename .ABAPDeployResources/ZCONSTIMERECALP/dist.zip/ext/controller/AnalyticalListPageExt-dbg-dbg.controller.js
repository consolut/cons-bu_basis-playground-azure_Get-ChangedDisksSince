sap.ui.controller("cons.consolutTimesheetAnalysis.ext.controller.AnalyticalListPageExt", {
	onInitSmartFilterBarExtension: function (oEvent) {
		var oFilterButton = this.getView().byId(
			"cons.consolutTimesheetAnalysis::sap.suite.ui.generic.template.AnalyticalListPage.view.AnalyticalListPage::Z_C_TIMESHEETANALYSIS--template::VisualFilterDialogButton"
		);
		oFilterButton.setVisible(false);
	}

});