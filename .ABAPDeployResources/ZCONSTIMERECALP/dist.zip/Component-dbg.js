jQuery.sap.declare("cons.consolutTimesheetAnalysis.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
sap.ui.define(["sap/ui/generic/app/AppComponent"], function (AppComponent) {
	return AppComponent.extend("cons.consolutTimesheetAnalysis.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});